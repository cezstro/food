export interface ICategory {
    categoryId?: number;
    name?: string;
    image?: string;
  }