import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { TitleCasePipe } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';     // for Inline css background

import { ICategory } from './Classes/category';
import { IItem } from './Classes/item';
import { debug } from 'util';

declare var $: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  
  categoryList: ICategory[];
  itemList: IItem[];
  itemRec: IItem;
  newItemRec: IItem;

  search: any;
  food_item: string = "assets/img/food_items/";

  constructor() { }

  ngOnInit() { 

    this.setDefaultValue();

    this.categoryList = [
      {
        categoryId: 1,
        name: "Test",
        image: "breakfast.jpeg"
      },
      {
        categoryId: 2,
        name: "Lunch",
        image: "lunch.jpg"
      },
      {
        categoryId: 3,
        name: "Dinner",
        image: "dinner.jpg"
      },
      {
        categoryId: 4,
        name: "Soup",
        image: "soup.jpg"
      },
      {
        categoryId: 5,
        name: "Salads",
        image: "salad.jpg"
      },
      {
        categoryId: 6,
        name: "Baking",
        image: "baking.jpg"
      },
      {
        categoryId: 6,
        name: "Drink",
        image: "drink.jpg"
      }

    ];

    this.itemList = [
      {
        itemId: 1,
        name: "The South's Best Fried Chicken",
        category: {
          categoryId: 1
        },
        description: "Fried Chicken with cheese1",
        image: "food1.jpg"
      },
      {
        itemId: 2,
        name: "The South's Best Fried Chicken",
        category: {
          categoryId: 2
        },
        description: "Fried Chicken with cheese2",
        image: "food2.jpg"
      },
      {
        itemId: 3,
        name: "The South's Best Fried Chicken",
        category: {
          categoryId: 3
        },
        description: "Fried Chicken with cheese3",
        image: "food3.jpg"
      }
    ];
  }

  setDefaultValue(): void {
    this.newItemRec = { 
      category: 1
    };
  }

  // Select By Id - Single record view
  viewRecFn(itemId: number): void {
    this.itemRec = this.itemList[itemId-1];
    //debugger;
    this.itemRec.category = this.categoryList[this.itemRec.category.categoryId-1].name;
  }

  // Add single record into array
  AddRecordFn = function(userdata: IItem) {
    //console.log(userdata);
    var obj = {
      categoryId: userdata.category
    }

    userdata.category = obj;
    userdata.image = "default.png";
    userdata.itemId = (this.itemList.length + 1);
    
    this.itemList.push(userdata);

    $(".addRec-modal").modal("hide");

    this.setDefaultValue();
  }
}
