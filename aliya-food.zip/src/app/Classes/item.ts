export interface IItem {
    itemId?: number;
    name?: string;
    category?: any;
    description?: string;
    image?: string;
  }